-- =============================================
-- Author:		Arnel Diola
-- Create date: 20250613
-- Description:	Gets all POS versions
-- Version: 007.062025
-- =============================================
ALTER PROCEDURE [dbo].[usp_GetAllPOSVersions]  
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT [POSVersionId]
		  ,[Name]
		  ,[Description]
		  ,[Path]
		  ,[CreatedBy]
		  ,[DateCreated]
		  ,[IsPreProdOnly]
		  ,[IsActive]
		  ,[Password]
		  ,[DBUpdatePath]
	FROM [dbo].[POSVersions]

END
