-- =============================================
-- Author:		Arnel Diola
-- Create date: 20250613
-- Description:	Gets latest active version
-- Version: 007.062025
-- =============================================
ALTER PROCEDURE [dbo].[usp_GetLatestActiveVersion]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
	SELECT TOP 1 [POSVersionId]
		  ,[Name]
		  ,[Description]
		  ,[Path]
		  ,[CreatedBy]
		  ,[DateCreated]
		  ,[IsPreProdOnly]
		  ,[IsActive]
		  ,[Password]
		  ,[DBUpdatePath]
	FROM [dbo].[POSVersions]
	WHERE IsActive = 1
	ORDER BY POSVersionId DESC

END
